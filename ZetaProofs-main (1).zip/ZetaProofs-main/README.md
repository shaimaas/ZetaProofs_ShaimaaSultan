# 16 Different ways to Proof Riemann hypnosis  

## $\textcolor{red}{ (1) New\ Odd\ Numbers\ Identity\ and\ The\ None-trivial\ Zeros\ of\ Zeta\ Function}$
  ---
  <img src="Screenshot 2024-01-18 173814.png" />
  <img src="Screenshot 2024-01-19 134904.png" />
  <img src="Screenshot 2024-01-19 130908.png" />
  
## $\textcolor{red}{ (2) Trigonometric\ Inverse\ Domain}$
  ---
  <img src="Screenshot 2024-01-19 175913.png" />
  <img src="Screenshot 2024-01-19 175823.png" />

## $\textcolor{red}{ (3) Synchronize\ Sin\ and\ Cos\ inverse\ Function} $
 ---
  <img src="Screenshot 2024-01-19 180319.png" />
  <img src="Screenshot 2024-01-19 180056.png" />
  
## $\textcolor{red}{ (4) Chain\ of\ Trigonometric\ functions\ Synchronization}$
  ---
  
   <img src= "Screenshot 2024-01-19 153543.png" />
   <img src="Screenshot 2024-01-19 153527.png" />
   
## $\textcolor{red}{ (5) Quadratic\ Equation\ Solution\ and\ prime\ numbers\ Filtering}$
  ---
  <img src="Screenshot 2024-01-19 145822.png" />
  
## $\textcolor{red}{ (6) Cubic\ Equation\ Solution\ for\ all\ Complete\ squares}$
  ---
  
   <img src="Screenshot 2024-01-19 145733.png" />
   <img src="Screenshot 2024-01-19 144213.png" />
   <img src="Screenshot 2024-01-19 145552.png" />
   <img src="Screenshot 2024-01-19 144233.png" />
   
## $\textcolor{red}{ (7) Cubic\ Twin\ Equation}$
  ---
  
   <img src="Screenshot 2024-01-19 144152.png" />
   
## $\textcolor{red}{ (8) Study\ Sin\ Term\ in\ Zeta\ functional\ function\ at S= S+ 0.5}$
  ---
  
  <img src="Screenshot 2024-01-19 131326.png" />
   
## $\textcolor{red}{ (9) Power\ functions}$
  ---
  
  <img src="Screenshot 2024-01-19 125510.png" />
  <img src="Screenshot 2024-01-19 125603.png" />
    
## $\textcolor{red}{ (10) Sum\ of\ Series\ of\ ones}$
  ---
  
   <img src="Screenshot 2024-01-07 064707.png" />
    
## $\textcolor{red}{ (11) one\ dgree\ in\ terms\ of\ imaginary\ unit\ number\ [i]}$
  ---
  
   <img src="Screenshot 2024-01-06 210726.png" />
   <img src="Screenshot 2024-01-06 210425.png" />

## $\textcolor{red}{ (12) Frame\ of\ Reference\ Even\ Function}$
  ---
   <img src="Screenshot 2024-01-06 205642.png" />
   <img src="Screenshot 2024-01-06 194717.png" />
   <img src="Screenshot 2024-01-06 201809.png" />
   <img src="Screenshot 2024-01-06 203846.png" />
   <img src="Screenshot 2024-01-06 204424.png" />
   <img src="Screenshot 2024-01-04 005946.png" />
   <img src="Screenshot 2024-01-06 205126.png" />
   <img src="Screenshot 2024-01-06 210044.png" />
   <img src="Screenshot 2024-01-06 205904.png" />
   <img src="Screenshot 2024-01-06 205837.png" />
   <img src="Screenshot 2024-01-06 205944.png" />
   <img src="Screenshot 2024-01-06 205904.png" />
   <img src="Screenshot 2024-01-06 205741.png" />
    
## $\textcolor{red}{  (13) using\ Absolut\ function\ and\ floor\ function} $
---

  <img src="Screenshot 2023-12-04 101927.png" />
  <img src="Screenshot 2023-12-04 102154.png" />
  <img src="Screenshot (3).png" />

 ## $\textcolor{red}{  (14) using\ Natural\ Log\ function\ }$
 ---
 
  <img src="Screenshot 2023-12-04 102952.png" />
  <img src="Screenshot 2023-12-04 103600.png" />
  <img src="Screenshot 2023-12-04 102818.png" />
  <img src="Screenshot 2023-12-04 103803.png" />
  <img src="Screenshot 2023-12-04 103850.png" />
  <img src="Screenshot 2023-12-04 104135.png" />
  <img src="Screenshot 2023-12-04 104946.png" />
  <img src="Screenshot 2023-12-04 105112.png" />
  <img src="Screenshot 2023-12-04 111221.png" />
  <img src="Screenshot 2023-12-04 111342.png" />
  <img src="Screenshot 2023-12-04 111601.png" />
  <img src="Screenshot 2023-12-04 111601.png" />
  <img src="Screenshot 2023-12-04 113948.png" />
  <img src="Screenshot 2023-12-04 114000.png" />
  <img src="Screenshot 2023-12-04 114416.png" />
  <img src="Screenshot 2023-12-04 114830.png" />
  <img src="Screenshot 2023-12-04 115030.png" />
  <img src="Screenshot 2023-12-04 134146.png" />
  <img src="Screenshot 2023-12-04 143654.png" />
  <img src="Screenshot 2023-12-04 161340.png" />
  <img src="Screenshot 2023-12-04 161712.png" />
  <img src="Screenshot 2023-12-04 183844.png" />
  <img src="Screenshot 2023-12-04 185733.png" />
  <img src="Screenshot 2023-12-04 185842.png" />
  <img src="Screenshot 2023-12-04 191637.png" />
  <img src="Screenshot 2023-12-25 172354.png" />
  <img src="Screenshot 2023-12-25 180442.png" />

   ## $\textcolor{red}{  (15) Using\ Euler's\ Identity\ as\ degree\ in\ Trigonometric\ functions}$
   ---

   <img src="Screenshot 2024-01-04 094913.png" /> 

  ## $\textcolor{red}{  (16) Sercret\ of\ 2\ and\ Square\ root\ of\ 2\}$
  ---

  <img src="Screenshot 2023-09-24 221459.jpg" />
  <img src="Screenshot 2023-06-30 232853.png" />
  <img src="Screenshot 2023-09-24 221536.jpg" />

  
  
 
  
    
    


  
  
  
